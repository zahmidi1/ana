<?php

namespace App\Policies;

use App\Models\User;
use App\Models\milk_reception;
use Illuminate\Auth\Access\HandlesAuthorization;

class MilkReceptionPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function viewAny(User $user)
    {
        //
    }

    /**
     * Determine whether the user can view the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\milk_reception  $milkReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function view(User $user, milk_reception $milkReception)
    {
        //
    }

    /**
     * Determine whether the user can create models.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function create(User $user)
    {
        //
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\milk_reception  $milkReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function update(User $user, milk_reception $milkReception)
    {
        //
    }

    /**
     * Determine whether the user can delete the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\milk_reception  $milkReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function delete(User $user, milk_reception $milkReception)
    {
        //
    }

    /**
     * Determine whether the user can restore the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\milk_reception  $milkReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function restore(User $user, milk_reception $milkReception)
    {
        //
    }

    /**
     * Determine whether the user can permanently delete the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\milk_reception  $milkReception
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function forceDelete(User $user, milk_reception $milkReception)
    {
        //
    }
}
