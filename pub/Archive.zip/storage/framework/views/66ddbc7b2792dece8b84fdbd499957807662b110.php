<?php $__env->startSection('namePage'); ?>
    dashboard
<?php $__env->stopSection(); ?>


<?php $__env->startSection('nav'); ?>
    <li class="mm-active"><a href="#" class="ai-icon mm-active" aria-expanded="false">
            <i class="flaticon-025-dashboard"></i>
            <span class="nav-text">Dashboard</span>
        </a>
    </li>



    <li><a href="/client" class="ai-icon " aria-expanded="false">
            <i class="flaticon-017-clipboard"></i>
            <span class="nav-text">Client</span>
        </a>
    </li>

    <li><a href="widget-basic.html" class="ai-icon" aria-expanded="false">
            <i class="flaticon-022-copy"></i>
            <span class="nav-text">Salarié</span>
        </a>
    </li>
    <li><a href="widget-basic.html" class="ai-icon" aria-expanded="false">
            <i class="flaticon-013-checkmark"></i>
            <span class="nav-text">Partenaire</span>
        </a>
    </li>
    <li><a href="widget-basic.html" class="ai-icon" aria-expanded="false">
            <i class="fa fa-user"></i>
            <span class="nav-text">Administration</span>
        </a>
    </li>
    <li><a href="widget-basic.html" class="ai-icon" aria-expanded="false">
            <i class="fa fa-paper-plane"></i>
            <span class="nav-text">Email</span>
        </a>
    </li>
    <li><a href="widget-basic.html" class="ai-icon" aria-expanded="false">
            <i class="fa fa-desktop" aria-hidden="true"></i>
            <span class="nav-text">Site Web</span>
        </a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    hiiiiiiiiiiiiiiiiiiiiiiiii
<?php $__env->stopSection(); ?>

<?php $__env->startSection('secript'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/zahmidi/Desktop/laravel/nasimAkhedar/resources/views/home.blade.php ENDPATH**/ ?>