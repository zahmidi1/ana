<?php $__env->startSection('namePage'); ?>
    receptions de lait
<?php $__env->stopSection(); ?>


<?php $__env->startSection('nav'); ?>
    <li><a href="#" class="ai-icon" aria-expanded="false">
            <i class="flaticon-025-dashboard"></i>
            <span class="nav-text">Dashboard</span>
        </a>
    </li>

    <li><a href="/client" class="ai-icon " aria-expanded="false">
            <i class="flaticon-044-menu"></i>
            <span class="nav-text">Client</span>
        </a>
    </li>
    <li class="mm-active"><a href="#" class="ai-icon mm-active" aria-expanded="false">
            <i class="flaticon-017-clipboard"></i>
            <span class="nav-text">receptions de lait </span>
        </a>
    </li>

    <li><a href="widget-basic.html" class="ai-icon" aria-expanded="false">
            <i class="flaticon-022-copy"></i>
            <span class="nav-text">Salarié</span>
        </a>
    </li>
    <li><a href="widget-basic.html" class="ai-icon" aria-expanded="false">
            <i class="flaticon-013-checkmark"></i>
            <span class="nav-text">Partenaire</span>
        </a>
    </li>
    <li><a href="widget-basic.html" class="ai-icon" aria-expanded="false">
            <i class="fa fa-user"></i>
            <span class="nav-text">Administration</span>
        </a>
    </li>
    <li><a href="widget-basic.html" class="ai-icon" aria-expanded="false">
            <i class="fa fa-paper-plane"></i>
            <span class="nav-text">Email</span>
        </a>
    </li>
    <li><a href="widget-basic.html" class="ai-icon" aria-expanded="false">
            <i class="fa fa-desktop" aria-hidden="true"></i>
            <span class="nav-text">Site Web</span>
        </a>
    </li>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>
    <table id="example5" class="display" style="min-width: 845px; min-height: 50%;">
        <thead>
            <tr>
                <th>
                    <div class="form-check custom-checkbox ms-2">
                        <input type="checkbox" class="form-check-input" id="checkAll" required="">
                        <label class="form-check-label" for="checkAll"></label>
                    </div>
                </th>
                <th>CONTRÔLEUR</th>
                <th> N client</th>
                <th>period</th>
                <th>quantity</th>
                <th>density</th>
                <th>heat</th>
                <th>date de payment</th>
                <th>date</th>

            </tr>
        </thead>
        <tbody>
            <tr>
                <?php $__currentLoopData = $milk_reception; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reception): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td>
                        <div class="form-check custom-checkbox ms-2">
                            <input type="checkbox" class="form-check-input" id="customCheckBox2" required="">
                            <label class="form-check-label" for="customCheckBox2"></label>
                        </div>
                    </td>

                    <td><?php echo e($reception->id_user); ?></td>
                    <td>00<?php echo e($reception->id_client); ?></td>
                    <td><?php echo e($reception->period); ?></td>
                    <td><?php echo e($reception->quantity); ?>L</td>
                    <td><?php echo e($reception->density); ?></td>
                    <td><?php echo e($reception->heat); ?>Cº</td>
                    <td><?php echo e($reception->date_payment); ?></td>
                    <td><?php echo e($reception->created_at); ?></td>


            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('secript'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/zahmidi/Desktop/laravel/nasimAkhedar/resources/views/milk_reception.blade.php ENDPATH**/ ?>